﻿# ============================================
# Password Protection (Credential Manager)
# ============================================

$target = "PARENTAL_CONTROL_TOGGLE"

try {
    $cred = Get-StoredCredential -Target $target
} catch {
    Write-Host "Credential '$target' not found. Exiting..."
    return
}

# Convert stored secure password to plain text
$storedPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
                   [Runtime.InteropServices.Marshal]::SecureStringToBSTR($cred.Password)
               )

# Ask user for password
$input = Read-Host "Enter parental control password" -AsSecureString
$plainInput = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
                [Runtime.InteropServices.Marshal]::SecureStringToBSTR($input)
              )

# Compare correctly
if ($plainInput -ne $storedPlain) {
    Write-Host "Incorrect password. Exiting..."
    return
}

# ============================================
# CONFIGURATION
# ============================================

$yamlPath = "C:\AdGuardHome\AdGuardHome\AdGuardHome.yaml"
$ruleName = "Block QUIC UDP 443"

# ============================================
# FUNCTIONS
# ============================================

function Add-YouTubeRules {
    $content = Get-Content $yamlPath -Raw

    if ($content -notmatch "\|\|youtube\.com\^") {
        $newRules = @(
            "  - '||youtube.com^'",
            "  - '||youtubei.googleapis.com^'",
            "  - '||googlevideo.com^'",
            "  - '||ytimg.com^'"
        ) -join "`r`n"

        $content = $content -replace "(?s)user_rules:\s*(?:-.*?)(\r?\n\S|$)", "user_rules:`r`n$newRules`r`n$1"
        Set-Content $yamlPath $content
        Write-Host "🔴 YouTube rules added."
    } else {
        Write-Host "YouTube rules already present."
    }
}

function Remove-YouTubeRules {
    $content = Get-Content $yamlPath -Raw
    $content = $content -replace "  - '?\|\|youtube.*?\^'?\r?\n?", ""
    Set-Content $yamlPath $content
    Write-Host "🟢 YouTube rules removed."
}

function Restart-AdGuard {
    Write-Host "Restarting AdGuard Home..."
    Restart-Service AdGuardHome
    Start-Sleep -Seconds 3
}

function Flush-DNS {
    Write-Host "Flushing Windows DNS..."
    ipconfig /flushdns | Out-Null
}

function Kill-Browsers {
    Write-Host "Closing browsers..."
    taskkill /IM chrome.exe /F /T 2>$null
    taskkill /IM msedge.exe /F /T 2>$null
}

function Toggle-QUIC {
    param([string]$mode)

    if ($mode -eq "Block") {
        if (-not (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue)) {
            New-NetFirewallRule -DisplayName $ruleName -Direction Outbound -Action Block -Protocol UDP -RemotePort 443 -Profile Any -Enabled True
        } else {
            Set-NetFirewallRule -DisplayName $ruleName -Enabled True
        }
        Write-Host "🔴 QUIC blocked."
    } else {
        if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
            Set-NetFirewallRule -DisplayName $ruleName -Enabled False
        }
        Write-Host "🟢 QUIC allowed."
    }
}

# ============================================
# MAIN LOGIC
# ============================================

Write-Host "`nParental Control Toggle:"
Write-Host "1 = Enable Parental Controls (Block YouTube)"
Write-Host "2 = Disable Parental Controls (Allow YouTube)"
$choice = Read-Host "Enter 1 or 2"

switch ($choice) {
    "1" {
        Add-YouTubeRules
        Toggle-QUIC "Block"
        Restart-AdGuard
        Flush-DNS
        Kill-Browsers
        Write-Host "`n🔴 Parental Controls ENABLED — YouTube is BLOCKED.`n"
    }
    "2" {
        Remove-YouTubeRules
        Toggle-QUIC "Allow"
        Restart-AdGuard
        Flush-DNS
        Kill-Browsers
        Write-Host "`n🟢 Parental Controls DISABLED — YouTube is ALLOWED.`n"
    }
    default {
        Write-Host "Invalid choice. No changes made."
    }
}
